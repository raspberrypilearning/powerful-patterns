#!/bin/python3

from p5 import *

def setup():
    size(400, 400)
  
def draw():
    lines = 10 * frame_count  # Use na largura/comprimento da forma para animar ao longo do tempo
    
    # Cores tartan McEwen
    # Cores quadradas básicas
    BLUE = Color(83, 143, 200)
    GREEN = Color(78, 163, 162)
    BASE_COLORS = [GREEN, BLUE]
    
    # Cores cruzadas
    YELLOW = Color(155, 176, 135)
    RED = Color(155, 129, 113)
    CROSS_COLORS = [YELLOW, RED]
    
    # Costura e cor de sobreposição
    GREY = Color(78, 99, 86)
    
    # Desenhe todos os quadrados alternados de base VERDE e AZUL
    no_stroke()
    y_coordinate = 0
    squares = width/square_size
    
    for i in range (int(squares)):
        gap = 0
        for j in range (int(squares)):
            fill(BASE_COLORS[j % 2])  # VERDE e AZUL
            rect(gap, y_coordinate, square_size, square_size)
            gap = gap + square_size
        y_coordinate = y_coordinate + square_size
    
    # Cruzes
    stroke(GREY)
   
    # Desenhe as cruzes alternadas AMARELO e VERMELHO
    for i in range (4):
        fill(YELLOW)
        cross = square_size / 2 - 2 
        for i in range (int(squares/2)):
            fill(CROSS_COLORS[i % 2])  # AMARELO e VERMELHO
            rect(cross, 0, 4, lines)  
            rect(0, cross, lines, 4) 
            cross = cross + 2 * square_size
        # Desenhe as cruzes de costura
        no_fill() 
        cross = square_size + square_size / 2 - 2
        for i in range (int(squares)): 
            rect(cross, 0, 4, lines) 
            rect(0, cross, lines, 4)
            cross = cross + square_size
  
    # Desenhe as linhas cinzas onde o material se sobrepõe
    no_stroke()
    fill(GREY, 100)
    gap = square_size - 4
    for i in range (int(squares)):
        rect(gap, 0, 8, lines)
        gap = gap + square_size
    gap = square_size - 4
    for i in range (int(squares)):
        rect(0, gap, lines, 8)
        gap = gap + square_size

print('🏴󠁧󠁢󠁳󠁣󠁴󠁿󠁢󠁳󠁣󠁴󠁿 Este é McEwen Tartan 🏴󠁧󠁢󠁳󠁣󠁴󠁿󠁧󠁢󠁳󠁣󠁴󠁿')
square_size = int(input('Qual tamanho de 🏴󠁧󠁢󠁳󠁣󠁴󠁿 tartan você gostaria? 20, 50 ou 100'))
  
run(frame_rate=10)
